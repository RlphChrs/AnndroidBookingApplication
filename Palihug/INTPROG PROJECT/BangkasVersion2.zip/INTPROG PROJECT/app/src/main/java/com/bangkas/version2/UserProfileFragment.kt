package com.bangkas.version2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView


class UserProfileFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_user_profile, container, false)


        // Set OnClickListener for the "Book Now" button
        view.findViewById<Button>(R.id.updateProf).setOnClickListener {
            // Create an instance of PaymentMethodFragment
            val paymentMethodFragment = EditUserProfileFragment()

            // Navigate to PaymentMethodFragment
            navigateToFragment(paymentMethodFragment)
        }

        return view
    }

    // Function to navigate to a specified fragment
    private fun navigateToFragment(fragment: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }


}